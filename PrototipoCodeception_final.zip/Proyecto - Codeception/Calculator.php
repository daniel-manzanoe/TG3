<?php
class Calculator
{
    /**
     * @assert (0, 0) == 0
     * @assert (0, 1) == 1
     * @assert (1, 0) == 1
     * @assert (1, 1) == 2
     * @assert (1, 2) == 4
     */
     
    function sumar($a, $b) {
        return ($a + $b);
    }

    function restar($a, $b) {
        return ($a - $b);
    }

    function multiplicar($a, $b) {
        return ($a * $b);
    }

    function dividir($a, $b) {
        if ($b == 0) {
            throw new \InvalidArgumentException("Division by zero is not possible");
        }
        return ($a / $b);
    }
}
?>
