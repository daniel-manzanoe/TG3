<?php

require_once '..\CODECEPTION PROYECTO\Calculator.php';

class CalculatorTest extends \Codeception\Test\Unit {

    /**
     * @var Calculator
     */
    protected $object;

    /**
     * Sets up the fixture, for example, opens a network connection.
     * This method is called before a test is executed.
     */
    protected function setUp() {
        $this->object = new Calculator;
    }

    /**
     * Tears down the fixture, for example, closes a network connection.
     * This method is called after a test is executed.
     */
    protected function tearDown() {
        
    }

    /**
     * Generated from @assert (0, 0) == 0.
     *
     * @covers Calculator::add
     */
    public function testSumar() {
        $this->assertEquals(
                0, $this->object->sumar(0, 0)
        );
    }

    /**
     * Generated from @assert (0, 1) == 1.
     *
     * @covers Calculator::add
     */
    public function testSumar2() {
        $this->assertEquals(
                1, $this->object->sumar(0, 1)
        );
    }

    /**
     * Generated from @assert (1, 0) == 1.
     *
     * @covers Calculator::add
     */
    public function testSumar3() {
        $this->assertEquals(
                1, $this->object->sumar(1, 0)
        );
    }

    /**
     * Generated from @assert (1, 1) == 2.
     *
     * @covers Calculator::add
     */
    public function testSumar4() {
        $this->assertEquals(
                2, $this->object->sumar(1, 1)
        );
    }

    /**
     * Generated from @assert (1, 2) == 4.
     *
     * @covers Calculator::add
     */
    public function testSumar5() {
        $this->assertEquals(
                3, $this->object->sumar(1, 2)
        );
    }
    
    public function testRestar() {
        $this->assertEquals(
                0, $this->object->restar(0, 0)
        );
    }

   
    public function testRestar1() {
        $this->assertEquals(
                -1, $this->object->restar(0, 1)
        );
    }

    
    public function testRestar2() {
        $this->assertEquals(
                1, $this->object->restar(1, 0)
        );
    }

    
    public function testRestar3() {
        $this->assertEquals(
                0, $this->object->restar(1, 1)
        );
    }

    
    public function testRestar4() {
        $this->assertEquals(
                -1, $this->object->restar(1, 2)
        );
    }
    
    public function testMultiplicar() {
        $this->assertEquals(
                0, $this->object->multiplicar(0, 0)
        );
    }

    
    public function testMultiplicar1() {
        $this->assertEquals(
                0, $this->object->multiplicar(0, 1)
        );
    }

    public function testMultiplicar2() {
        $this->assertEquals(
                0, $this->object->multiplicar(1, 0)
        );
    }

    
    public function testMultiplicar3() {
        $this->assertEquals(
                1, $this->object->multiplicar(1, 1)
        );
    }

   
    public function testMultiplicar4() {
        $this->assertEquals(
                2, $this->object->multiplicar(1, 2)
        );
    }
    /**
     * @expectedException \InvalidArgumentException
     */
    public function testDividir() {
        $this->object->dividir(0, 0);
    }

    
    public function testDividir1() {
        $this->assertEquals(
                0, $this->object->dividir(0, 1)
        );
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testDividir2() {
        $this->object->dividir(1, 0);
    }

    
    public function testDividir3() {
        $this->assertEquals(
                1, $this->object->dividir(1, 1)
        );
    }

    public function testDividir4() {
        $this->assertEquals(
                0.5, $this->object->dividir(1, 2)
        );
    }
}
